# SubCreator Sponge Build Script
# Usage: "bash build.sh <forge version> <sponge version>"
#
#!/usr/bin/env bash
if [ -z "$1" ]
  then
    echo ERROR: No Build Version Supplied
    rm -Rf $0
    exit 1
fi
if [ -z "$2" ]
  then
    echo ERROR: No Build Version Supplied
    rm -Rf $0
    exit 1
fi
function __DL() {
    if [ hash wget 2>/dev/null ]; then
        wget -o $1 $2; return $?
    else
        curl -o $1 $2; return $?
    fi
}
echo Downloading Minecraft Forge...
__DL forge-$1-installer.jar http://files.minecraftforge.net/maven/net/minecraftforge/forge/$1/forge-$1-installer.jar; retvalg=$?
if [ $retvalg -eq 0 ]; then
    echo Installing Minecraft Forge Server...
    java -jar ./forge-$1-installer.jar --installServer; retvalh=$?
    if [ $retvalh -eq 0 ]; then
        mkdir ./mods
        echo Downloading SpongeForge...
        __DL mods/Sponge.jar http://files.minecraftforge.net/maven/org/spongepowered/spongeforge/$2/spongeforge-$2.jar; retvali=$?
        if [ $retvali -eq 0 ]; then
            echo Cleaning Up...
            rm -Rf forge-$1-installer.jar
            rm -Rf forge-$1-installer.jar.log
            mv -f forge-$1-universal.jar Forge.jar
            rm -Rf $0
            exit 0
        else
            echo ERROR: Failed Downloading Jarfile. Is MinecraftForge.net down?
            rm -Rf forge-$1-installer.jar
            rm -Rf forge-$1-installer.jar.log
            rm -Rf forge-$1-universal.jar
            rm -Rf $0
            exit 5
        fi
    else
        echo ERROR: Failed Installing Forge.
        rm -Rf forge-$1-installer.jar
        rm -Rf forge-$1-installer.jar.log
        rm -Rf $0
        exit 4
    fi
else
    echo ERROR: Failed Downloading Jarfile. Is MinecraftForge.net down?
    rm -Rf $0
    exit 3
fi
exit 2