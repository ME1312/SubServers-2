# SubCreator Spigot Build Script
# Usage: "bash build.sh <version> [cache]"
#
#!/usr/bin/env bash
if [ -z "$1" ]
  then
    echo ERROR: No Build Version Supplied
    rm -Rf $0
    exit 1
fi
function __DL() {
    if [ hash wget 2>/dev/null ]; then
        wget -o $1 $2; return $?
    else
        curl -o $1 $2; return $?
    fi
}
if [ -z "$2" ] || [ ! -f "$2/Spigot-$1.jar" ]; then
	echo Downloading Buildtools...
	__DL BuildTools.jar https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar; retvalb=$?
	if ! [ $retvalb -eq 0 ]; then
		echo ERROR: Failed Downloading Buildtools. Is SpigotMC.org down?
		rm -Rf $0
		exit 3
	fi
	if [ -d "Buildtools" ]; then
		rm -Rf Buildtools
	fi
	mkdir Buildtools
	cd "Buildtools"
	echo Launching BuildTools.jar
	export MAVEN_OPTS="-Xms2G"
	java -Xms2G -jar ../BuildTools.jar --rev $1; retvalc=$?
	cd ../
	if [ $retvalc -eq 0 ]; then
		echo Copying Final Jar...
		if [ ! -z "$2" ] && [ -d "$2" ]; then
			cp Buildtools/spigot-*.jar "$2/Spigot-$1.jar"
		fi
		cp Buildtools/spigot-*.jar Spigot.jar
		echo Cleaning Up...
		rm -Rf BuildTools.jar
		rm -Rf Buildtools
		rm -Rf $0
		exit 0
	else
		echo ERROR: Buildtools exited with an error. Please try again
		rm -Rf BuildTools.jar
		rm -Rf Buildtools
		rm -Rf $0
		exit 4
	fi
else
	echo Copying Cached Jar...
	cp "$2/Spigot-$1.jar" Spigot.jar
	echo Cleaning Up...
	rm -Rf $0
	exit 0
fi
exit 2