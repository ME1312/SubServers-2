# SubCreator Spigot Build Script
# Usage: "bash build.sh <version> [home]"
#
#!/usr/bin/env bash
if [ -z "$1" ]
  then
    echo ERROR: No Build Version Supplied
    rm -Rf $0
    exit 1
fi
function __DL() {
    if [ hash wget 2>/dev/null ]; then
        wget -o $1 $2; return $?
    else
        curl -o $1 $2; return $?
    fi
}
echo Downloading Buildtools...
__DL BuildTools.jar https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar; retvalb=$?
if ! [ $retvalb -eq 0 ]; then
    echo ERROR: Failed Downloading Buildtools. Is SpigotMC.org down?
    rm -Rf $0
    exit 3
fi
if [ -d "Buildtools" ]; then
    rm -Rf Buildtools
fi
mkdir Buildtools
cd "Buildtools"
echo Launching BuildTools.jar
export MAVEN_OPTS="-Xms2G"
if [ -z "$2" ]; then
    java -Xms2G -jar ../BuildTools.jar --rev $1; retvalc=$?
else
    HOME=$2 java -Xms2G -jar ../BuildTools.jar --rev $1; retvalc=$?
fi
cd ../
if [ $retvalc -eq 0 ]; then
    echo Copying Final Jar...
    cp Buildtools/spigot-*.jar Spigot.jar
    echo Cleaning Up...
    rm -Rf BuildTools.jar
    rm -Rf Buildtools
    rm -Rf $0
    exit 0
else
    echo ERROR: Buildtools exited with an error. Please try again
    rm -Rf BuildTools.jar
    rm -Rf Buildtools
    rm -Rf $0
    exit 4
fi
exit 2