# SubCreator Vanilla Build Script
# Usage: "bash build.sh <version> <patch> [home]"
#
#!/usr/bin/env bash
if [ -z "$1" ]
  then
    echo ERROR: No Build Version Supplied
    rm -Rf $0
    exit 1
fi
if [ -z "$2" ]
  then
    echo ERROR: No Patch Version Supplied
    rm -Rf $0
    exit 1
fi
function __DL() {
    if [ hash wget 2>/dev/null ]; then
        wget -o $1 $2; return $?
    else
        curl -o $1 $2; return $?
    fi
}
if [ -d "Buildtools" ]; then
    rm -Rf Buildtools
fi
mkdir Buildtools
mkdir Buildtools/Vanilla
echo Downloading Vanilla Jar...
__DL Buildtools/Vanilla/minecraft_server.$1.jar https://s3.amazonaws.com/Minecraft.Download/versions/$1/minecraft_server.$1.jar; retvald=$?
if [ $retvald -eq 0 ]; then
    echo Downloading Vanilla Patches...
    __DL Buildtools/Vanilla/bungee-patch.jar https://raw.githubusercontent.com/ME1312/SubServers-2/$2/SubServers.Bungee/Vanilla-Patch.jar; retvale=$?
    if [ $retvale -eq 0 ]; then
        echo Patching Vanilla for BungeeCord Support
        cd Buildtools/Vanilla
        if [ -z "$3" ]; then
            java -jar bungee-patch.jar $1; retvalf=$?;
        else
            HOME=$3 java -jar bungee-patch.jar $1; retvalf=$?;
        fi
        if [ $retvalf -eq 0 ]; then
            echo Copying Final Jar...
            cd ../../
            cp Buildtools/Vanilla/out/$1-bungee.jar Buildtools/vanilla-$1.jar
            cp Buildtools/Vanilla/out/$1-bungee.jar Vanilla.jar
            echo Cleaning Up...
            rm -Rf Buildtools
            rm -Rf $0
            exit 0
        else
            echo ERROR: Failed Applying Patch.
            rm -Rf Buildtools
            rm -Rf $0
            exit 5
        fi
    else
        echo ERROR: Failed Downloading Patch. Is Github.com down?
        rm -Rf Buildtools
        rm -Rf $0
        exit 4
    fi
else
    echo ERROR: Failed Downloading Jarfile. Is Minecraft.net down?
    rm -Rf Buildtools
    rm -Rf $0
    exit 3
fi
exit 2