# SubCreator Vanilla Build Script
# Usage: "bash build.sh <version> <patch> [cache]"
#
#!/usr/bin/env bash
if [ -z "$1" ]
  then
    echo ERROR: No Build Version Supplied
    rm -Rf $0
    exit 1
fi
if [ -z "$2" ]
  then
    echo ERROR: No Patch Version Supplied
    rm -Rf $0
    exit 1
fi
function __DL() {
    if [ hash wget 2>/dev/null ]; then
        wget -o $1 $2; return $?
    else
        curl -o $1 $2; return $?
    fi
}
if [ -z "$3" ] || [ ! -f "$3/Vanilla-$1.jar" ]; then
	if [ -d "Buildtools" ]; then
		rm -Rf Buildtools
	fi
	mkdir Buildtools
	mkdir Buildtools/Vanilla
	echo Downloading Vanilla Jar...
	__DL Buildtools/Vanilla/minecraft_server.$1.jar https://s3.amazonaws.com/Minecraft.Download/versions/$1/minecraft_server.$1.jar; retvald=$?
	if [ $retvald -eq 0 ]; then
		echo Downloading Vanilla Patches...
		__DL Buildtools/Vanilla/bungee-patch.jar https://raw.githubusercontent.com/ME1312/SubServers-2/$2/SubServers.Bungee/Vanilla-Patch.jar; retvale=$?
		if [ $retvale -eq 0 ]; then
			echo Patching Vanilla for BungeeCord Support
			cd Buildtools/Vanilla
			java -jar bungee-patch.jar $1; retvalf=$?;
			if [ $retvalf -eq 0 ]; then
				echo Copying Final Jar...
				cd ../../
				if [ ! -z "$3" ] && [ -d "$3" ]; then
					cp Buildtools/Vanilla/out/$1-bungee.jar "$3/Vanilla-$1.jar"
				fi
				cp Buildtools/Vanilla/out/$1-bungee.jar Vanilla.jar
				echo Cleaning Up...
				rm -Rf Buildtools
				rm -Rf $0
				exit 0
			else
				echo ERROR: Failed Applying Patch.
				rm -Rf Buildtools
				rm -Rf $0
				exit 5
			fi
		else
			echo ERROR: Failed Downloading Patch. Is Github.com down?
			rm -Rf Buildtools
			rm -Rf $0
			exit 4
		fi
	else
		echo ERROR: Failed Downloading Jarfile. Is Minecraft.net down?
		rm -Rf Buildtools
		rm -Rf $0
		exit 3
	fi
else
	echo Copying Cached Jar...
	cp "$3/Vanilla-$1.jar" Vanilla.jar
	echo Cleaning Up...
	rm -Rf $0
	exit 0
fi
exit 2